package com.springboot.magicBooks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MagicBooksApplicationTests {

	@Test
	void contextLoads() {
	}

}
