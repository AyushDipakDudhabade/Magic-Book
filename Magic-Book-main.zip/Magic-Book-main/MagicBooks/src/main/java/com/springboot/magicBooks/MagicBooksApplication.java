package com.springboot.magicBooks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MagicBooksApplication {

	public static void main(String[] args) {
		SpringApplication.run(MagicBooksApplication.class, args);
	}

}
